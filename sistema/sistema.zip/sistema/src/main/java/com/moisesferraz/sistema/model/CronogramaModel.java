package com.moisesferraz.sistema.model;

import java.util.Date;
import java.util.UUID;

public class CronogramaModel {
    private UUID id;
    private String disciplina;
    private Date data;
}
