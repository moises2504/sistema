package com.moisesferraz.sistema.model;

import java.time.LocalDate;
import java.util.UUID;

public class ProfessorModel {
    private UUID id;
    private String nome;
    private String email;
    private LocalDate nascimento;
    private String enderco;
    private String senha;
    private String telefone;
}
