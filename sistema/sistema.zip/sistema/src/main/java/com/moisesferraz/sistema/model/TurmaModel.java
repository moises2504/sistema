package com.moisesferraz.sistema.model;

import java.time.LocalDate;
import java.util.Date;
import java.util.UUID;

public class TurmaModel {
    private UUID id;
    private String disciplina;
    private Date data;

}
