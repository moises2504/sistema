package com.moisesferraz.sistema.model;

import java.util.UUID;

public class DisciplinaModel {
    private UUID id;
    private String nome;

}
