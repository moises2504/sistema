package com.moisesferraz.sistema.model;

import java.util.UUID;

public class AtendimentoModel {
    private UUID id;
    private String descricao;
}
