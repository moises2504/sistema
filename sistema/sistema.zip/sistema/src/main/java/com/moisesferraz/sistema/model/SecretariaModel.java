package com.moisesferraz.sistema.model;

import java.time.LocalDate;
import java.util.UUID;

public class SecretariaModel {
    private UUID id;
    private String nome;
    private String email;
    private String senha;

}
