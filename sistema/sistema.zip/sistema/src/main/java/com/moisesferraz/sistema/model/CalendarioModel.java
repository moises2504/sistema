package com.moisesferraz.sistema.model;

import java.util.Date;
import java.util.UUID;

public class CalendarioModel {
    private UUID id;
    private String nome;
    private Date data;

}
